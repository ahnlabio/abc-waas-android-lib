package io.ahnlab.abcwaas

import io.ahnlab.abcmpc.ABCMpc
import io.ahnlab.abcmpc.MpcError
import io.ahnlab.abcmpc.SignResponse
import org.json.JSONObject
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

sealed class XRPHelperError(override val message: String) : Exception(message) {
    class WaasError(val error: io.ahnlab.abcwaas.WaasError) :
        XRPHelperError("Waas error: ${error.message}")
    
    class MpcError(val error: io.ahnlab.abcmpc.MpcError) :
        XRPHelperError("Mpc error: ${error.message}")
    
    class UnknownError(override val message: String) : 
        XRPHelperError(message)

    val description: String
        get() = message
}

// JSON 설정
private val json = Json {
    ignoreUnknownKeys = true  // 모델에 없는 키는 무시
    isLenient = true          // 따옴표 없는 키 등 허용
    coerceInputValues = true  // 기본값이 있는 경우 누락된 필드 처리
}

@Serializable
data class XRPAccount(
    val account: String
)

@Serializable
data class XRPBalance(
    val balance: String,
    val available: String,
    val reserve: String
)

@Serializable
data class XRPTransaction(
    val txHash: String
)

@Serializable
data class XRPTrustlineInfo(
    val currency: String,
    val issuer: String,
    val balance: String,
    val limit: String,
    val limit_peer: String,
    val quality_in: Int,
    val quality_out: Int,
    val no_ripple: Boolean,
    val no_ripple_peer: Boolean,
    val authorized: Boolean,
    val peer_authorized: Boolean,
    val freeze: Boolean,
    val freeze_peer: Boolean
)

@Serializable
data class XRPTrustline(
    val success: Boolean,
    val account: String,
    val issuer: String,
    val currency: String,
    val trust_line_exists: Boolean,
    val trust_line_info: XRPTrustlineInfo?,
    val error: String?
)

@Serializable
data class XRPFtBalance(
    val success: Boolean,
    val account: String,
    val tokens: List<XRPTrustlineInfo>,
    val error: String?
)

public class XRPHelper(
    private val waasClient: WaasClient?,
    private val node1BaseURL: String,
    private val node2BaseURL: String
) {

    // MARK: - Basic XRP Functions

    public suspend fun sign(
        accessToken: String,
        keyId: String,
        encryptedShare: String,
        secretStore: String,
        curve: String,
        message: String,
        password: String
    ): Result<SignResponse> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyId)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(XRPHelperError.WaasError(error))
                    else -> Result.failure(XRPHelperError.UnknownError("Wallet Data Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 2. 서명
            val signResult = ABCMpc.getInstance().sign(
                node_1_url = node1BaseURL,
                token = walletTokenResponse.token,
                key_id = keyId,
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                curve = curve,
                message = message,
                password = password
            )
            if (signResult.isFailure) {
                return when (val error = signResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(XRPHelperError.MpcError(error))
                    else -> Result.failure(XRPHelperError.UnknownError("Message Signing Failed"))
                }
            }
            val signResponse = signResult.getOrThrow()

            return Result.success(signResponse)
        } catch (e: Exception) {
            Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    /// XRP 계정 생성
    public suspend fun getAccount(
        accessToken: String,
        publicKey: String,
        network: String
    ): Result<XRPAccount> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
            }

            val result = waasClient.postV2XrpAccount(accessToken, publicKey, network)
            if (result.isFailure) {
                return when (val error = result.exceptionOrNull()) {
                    is WaasError -> Result.failure(XRPHelperError.WaasError(error))
                    else -> Result.failure(XRPHelperError.UnknownError("Failed to create XRP account"))
                }
            }
            val response = result.getOrThrow()

            // ByteArray를 String으로 변환 후 JSON 파싱
            val jsonString = String(response, Charsets.UTF_8)
            
            val accountResponse = json.decodeFromString<XRPAccount>(jsonString)
            Result.success(accountResponse)
        } catch (e: Exception) {
            Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    /// XRP 잔액 조회
    public suspend fun getBalance(
        accessToken: String,
        account: String,
        network: String
    ): Result<XRPBalance> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
            }

            val result = waasClient.postV2XrpBalance(accessToken, account, network)
            if (result.isFailure) {
                return when (val error = result.exceptionOrNull()) {
                    is WaasError -> Result.failure(XRPHelperError.WaasError(error))
                    else -> Result.failure(XRPHelperError.UnknownError("Failed to get XRP balance"))
                }
            }
            val response = result.getOrThrow()

            val jsonString = String(response, Charsets.UTF_8)
            val balanceResponse = json.decodeFromString<XRPBalance>(jsonString)

            Result.success(balanceResponse)
        } catch (e: Exception) {
            Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    // // XRP 전송
    // public suspend fun transferXRP(
    //     accessToken: String,
    //     keyId: String,
    //     encryptedShare: String,
    //     secretStore: String,
    //     curve: String,
    //     account: String,
    //     amount: String,
    //     destination: String,
    //     destinationTag: String?,
    //     fee: String?,
    //     publicKey: String,
    //     network: String
    // ): Result<XRPTransaction> {
    //     return try {
    //         // 0. waasClient 널 체크
    //         if (waasClient == null) {
    //             return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
    //         }

    //         // fee가 null이면 기본 수수료 조회
    //         var finalFee = fee
    //         if (fee == null) {
    //             val feeResult = waasClient.postV2XrpFee(accessToken, network)
    //             if (feeResult.isFailure) {
    //                 return when (val error = feeResult.exceptionOrNull()) {
    //                     is WaasError -> Result.failure(XRPHelperError.WaasError(error))
    //                     else -> Result.failure(XRPHelperError.UnknownError("Failed to get XRP fee"))
    //                 }
    //             }
    //             val feeResponse = feeResult.getOrThrow()

    //             // JSON에서 base_fee 추출
    //             val json = JSONObject(String(feeResponse, Charsets.UTF_8))
    //             val dataDict = json.optJSONObject("data")
    //             val rawFeeData = dataDict?.optJSONObject("raw_fee_data")
    //             val drops = rawFeeData?.optJSONObject("drops")
    //             val baseFee = drops?.optString("base_fee")
                
    //             if (baseFee.isNullOrEmpty()) {
    //                 return Result.failure(XRPHelperError.UnknownError("Failed to extract fee"))
    //             }
                
    //             finalFee = baseFee
    //         }

    //         val result = waasClient.postV2XrpTransfer(
    //             accessToken, account, amount, destination, destinationTag, finalFee!!, publicKey, network
    //         )
    //         if (result.isFailure) {
    //             return when (val error = result.exceptionOrNull()) {
    //                 is WaasError -> Result.failure(XRPHelperError.WaasError(error))
    //                 else -> Result.failure(XRPHelperError.UnknownError("Failed to transfer XRP"))
    //             }
    //         }
    //         val response = result.getOrThrow()

    //         // serialized_tx 추출
    //         val json = JSONObject(String(response, Charsets.UTF_8))
    //         val dataDict = json.optJSONObject("data")
    //         val serializedTx = dataDict?.optString("serialized_tx")
    //         if (serializedTx.isNullOrEmpty()) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to extract serialized_tx"))
    //         }

    //         // hash 추출
    //         val hash = dataDict?.optString("hash")
    //         if (hash.isNullOrEmpty()) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to extract hash"))
    //         }

    //         // 서명
    //         val signResult = sign(
    //             accessToken = accessToken,
    //             keyId = keyId,
    //             encryptedShare = encryptedShare,
    //             secretStore = secretStore,
    //             curve = curve,
    //             message = hash
    //         )
    //         if (signResult.isFailure) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to sign transaction"))
    //         }
    //         val signResponse = signResult.getOrThrow()

    //         // 트랜잭션 전송
    //         val sendTransactionResult = waasClient.postV2XrpSendTransaction(
    //             accessToken, publicKey, serializedTx, signResponse.signature, network
    //         )
    //         if (sendTransactionResult.isFailure) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to send transaction"))
    //         }
    //         val sendTransactionResponse = sendTransactionResult.getOrThrow()

    //         // tx_hash 추출
    //         val sendJson = JSONObject(String(sendTransactionResponse, Charsets.UTF_8))
    //         val sendDataDict = sendJson.optJSONObject("data")
    //         val txHash = sendDataDict?.optString("hash")
    //         if (txHash.isNullOrEmpty()) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to extract tx_hash"))
    //         }

    //         Result.success(XRPTransaction(txHash))
    //     } catch (e: Exception) {
    //         Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
    //     }
    // }

    // // XRP Trustline 조회
    // public suspend fun getTrustline(
    //     accessToken: String,
    //     account: String,
    //     currency: String,
    //     issuer: String,
    //     network: String
    // ): Result<XRPTrustline> {
    //     return try {
    //         // 0. waasClient 널 체크
    //         if (waasClient == null) {
    //             return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
    //         }

    //         val result = waasClient.postV2XrpTrustlineStatus(accessToken, account, currency, issuer, network)
    //         if (result.isFailure) {
    //             return when (val error = result.exceptionOrNull()) {
    //                 is WaasError -> Result.failure(XRPHelperError.WaasError(error))
    //                 else -> Result.failure(XRPHelperError.UnknownError("Failed to get XRP trustline status"))
    //             }
    //         }
    //         val response = result.getOrThrow()

    //         // JSON 파싱
    //         val json = JSONObject(String(response, Charsets.UTF_8))
    //         val success = json.optBoolean("success", false)
    //         val accountStr = json.optString("account")
    //         val issuerStr = json.optString("issuer")
    //         val currencyStr = json.optString("currency")
    //         val trustLineExists = json.optBoolean("trust_line_exists", false)
    //         val error = json.optString("error").takeIf { it.isNotEmpty() }

    //         val trustLineInfo: XRPTrustlineInfo? = if (trustLineExists) {
    //             val trustLineInfoDict = json.optJSONObject("trust_line_info")
    //             if (trustLineInfoDict != null) {
    //                 XRPTrustlineInfo(
    //                     currency = trustLineInfoDict.optString("currency"),
    //                     issuer = trustLineInfoDict.optString("issuer"),
    //                     balance = trustLineInfoDict.optString("balance"),
    //                     limit = trustLineInfoDict.optString("limit"),
    //                     limit_peer = trustLineInfoDict.optString("limit_peer"),
    //                     quality_in = trustLineInfoDict.optInt("quality_in"),
    //                     quality_out = trustLineInfoDict.optInt("quality_out"),
    //                     no_ripple = trustLineInfoDict.optBoolean("no_ripple"),
    //                     no_ripple_peer = trustLineInfoDict.optBoolean("no_ripple_peer"),
    //                     authorized = trustLineInfoDict.optBoolean("authorized"),
    //                     peer_authorized = trustLineInfoDict.optBoolean("peer_authorized"),
    //                     freeze = trustLineInfoDict.optBoolean("freeze"),
    //                     freeze_peer = trustLineInfoDict.optBoolean("freeze_peer")
    //                 )
    //             } else null
    //         } else null

    //         Result.success(XRPTrustline(
    //             success = success,
    //             account = accountStr,
    //             issuer = issuerStr,
    //             currency = currencyStr,
    //             trust_line_exists = trustLineExists,
    //             trust_line_info = trustLineInfo,
    //             error = error
    //         ))
    //     } catch (e: Exception) {
    //         Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
    //     }
    // }

    // // XRP Trustline 설정
    // public suspend fun setTrustline(
    //     accessToken: String,
    //     keyId: String,
    //     encryptedShare: String,
    //     secretStore: String,
    //     curve: String,
    //     account: String,
    //     currency: String,
    //     fee: String?,
    //     issuer: String,
    //     limit: String,
    //     publicKey: String,
    //     network: String
    // ): Result<XRPTransaction> {
    //     return try {
    //         // 0. waasClient 널 체크
    //         if (waasClient == null) {
    //             return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
    //         }

    //         // fee가 null이면 기본 수수료 조회
    //         var finalFee = fee
    //         if (fee == null) {
    //             val feeResult = waasClient.postV2XrpFee(accessToken, network)
    //             if (feeResult.isFailure) {
    //                 return when (val error = feeResult.exceptionOrNull()) {
    //                     is WaasError -> Result.failure(XRPHelperError.WaasError(error))
    //                     else -> Result.failure(XRPHelperError.UnknownError("Failed to get XRP fee"))
    //                 }
    //             }
    //             val feeResponse = feeResult.getOrThrow()

    //             // JSON에서 base_fee 추출
    //             val json = JSONObject(String(feeResponse, Charsets.UTF_8))
    //             val dataDict = json.optJSONObject("data")
    //             val rawFeeData = dataDict?.optJSONObject("raw_fee_data")
    //             val drops = rawFeeData?.optJSONObject("drops")
    //             val baseFee = drops?.optString("base_fee")
                
    //             if (baseFee.isNullOrEmpty()) {
    //                 return Result.failure(XRPHelperError.UnknownError("Failed to extract fee"))
    //             }
                
    //             finalFee = baseFee
    //         }

    //         val result = waasClient.postV2XrpTrustline(
    //             accessToken, account, currency, finalFee!!, issuer, limit, publicKey, network
    //         )
    //         if (result.isFailure) {
    //             return when (val error = result.exceptionOrNull()) {
    //                 is WaasError -> Result.failure(XRPHelperError.WaasError(error))
    //                 else -> Result.failure(XRPHelperError.UnknownError("Failed to create XRP trustline"))
    //             }
    //         }
    //         val response = result.getOrThrow()

    //         // serialized_tx 추출
    //         val json = JSONObject(String(response, Charsets.UTF_8))
    //         val dataDict = json.optJSONObject("data")
    //         val serializedTx = dataDict?.optString("serialized_tx")
    //         if (serializedTx.isNullOrEmpty()) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to extract serialized_tx"))
    //         }

    //         // hash 추출
    //         val hash = dataDict?.optString("hash")
    //         if (hash.isNullOrEmpty()) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to extract hash"))
    //         }

    //         // 서명
    //         val signResult = sign(
    //             accessToken = accessToken,
    //             keyId = keyId,
    //             encryptedShare = encryptedShare,
    //             secretStore = secretStore,
    //             curve = curve,
    //             message = hash
    //         )
    //         if (signResult.isFailure) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to sign transaction"))
    //         }
    //         val signResponse = signResult.getOrThrow()

    //         // 트랜잭션 전송
    //         val sendTransactionResult = waasClient.postV2XrpSendTransaction(
    //             accessToken, publicKey, serializedTx, signResponse.signature, network
    //         )
    //         if (sendTransactionResult.isFailure) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to send transaction"))
    //         }
    //         val sendTransactionResponse = sendTransactionResult.getOrThrow()

    //         // tx_hash 추출
    //         val sendJson = JSONObject(String(sendTransactionResponse, Charsets.UTF_8))
    //         val sendDataDict = sendJson.optJSONObject("data")
    //         val txHash = sendDataDict?.optString("hash")
    //         if (txHash.isNullOrEmpty()) {
    //             return Result.failure(XRPHelperError.UnknownError("Failed to extract tx_hash"))
    //         }

    //         Result.success(XRPTransaction(txHash))
    //     } catch (e: Exception) {
    //         Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
    //     }
    // }

    // // XRP FT 잔액 조회
    // public suspend fun getFtBalance(
    //     accessToken: String,
    //     account: String,
    //     issuer: String,
    //     network: String
    // ): Result<XRPFtBalance> {
    //     return try {
    //         // 0. waasClient 널 체크
    //         if (waasClient == null) {
    //             return Result.failure(XRPHelperError.UnknownError("WaasClient is not initialized"))
    //         }

    //         val result = waasClient.postV2XrpFtBalance(accessToken, account, issuer, network)
    //         if (result.isFailure) {
    //             return when (val error = result.exceptionOrNull()) {
    //                 is WaasError -> Result.failure(XRPHelperError.WaasError(error))
    //                 else -> Result.failure(XRPHelperError.UnknownError("Failed to get XRP FT balance"))
    //             }
    //         }
    //         val response = result.getOrThrow()

    //         // JSON 파싱
    //         val json = JSONObject(String(response, Charsets.UTF_8))
    //         val success = json.optBoolean("success", false)
    //         val accountStr = json.optString("account")
    //         val error = json.optString("error").takeIf { it.isNotEmpty() }

    //         val tokensArray = json.optJSONArray("tokens")
    //         val tokens = mutableListOf<XRPTrustlineInfo>()
            
    //         if (tokensArray != null) {
    //             for (i in 0 until tokensArray.length()) {
    //                 val tokenDict = tokensArray.getJSONObject(i)
    //                 val tokenInfo = XRPTrustlineInfo(
    //                     currency = tokenDict.optString("currency"),
    //                     issuer = tokenDict.optString("issuer"),
    //                     balance = tokenDict.optString("balance"),
    //                     limit = tokenDict.optString("limit"),
    //                     limit_peer = tokenDict.optString("limit_peer"),
    //                     quality_in = tokenDict.optInt("quality_in"),
    //                     quality_out = tokenDict.optInt("quality_out"),
    //                     no_ripple = tokenDict.optBoolean("no_ripple"),
    //                     no_ripple_peer = tokenDict.optBoolean("no_ripple_peer"),
    //                     authorized = tokenDict.optBoolean("authorized"),
    //                     peer_authorized = tokenDict.optBoolean("peer_authorized"),
    //                     freeze = tokenDict.optBoolean("freeze"),
    //                     freeze_peer = tokenDict.optBoolean("freeze_peer")
    //                 )
    //                 tokens.add(tokenInfo)
    //             }
    //         }

    //         Result.success(XRPFtBalance(
    //             success = success,
    //             account = accountStr,
    //             tokens = tokens,
    //             error = error
    //         ))
    //     } catch (e: Exception) {
    //         Result.failure(XRPHelperError.UnknownError("error: ${e.localizedMessage}"))
    //     }
    // }
}
