package io.ahnlab.abcwaas
// Data classes for res
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class WalletResponse(
    @SerialName("user_id")
    val userId: String,
    val wallets: List<Wallet>
)

@Serializable
data class Wallet(
    val key: Key,
    val address: Address
)

@Serializable
data class Key(
    val curve: String,

    @SerialName("public_key")
    val publicKey: String
)

@Serializable
data class Address(
    val solana: String? = null,
    val evm: String? = null,
    val btc: String? = null,
    val aptos: String? = null
)

@Serializable
data class WalletUserResponse(
    @SerialName("user_id")
    val userId: String,

    val key: List<UserKey>
)

@Serializable
data class UserKey(
    val id: String,
    val curve: String,

    @SerialName("public_key")
    val publicKey: String,

    @SerialName("created_at")
    val createdAt: String
) 

typealias WalletKeyResponse = List<UserKey>
typealias WalletKey = UserKey

@Serializable
data class WalletTokenResponse(
    val token: String
)