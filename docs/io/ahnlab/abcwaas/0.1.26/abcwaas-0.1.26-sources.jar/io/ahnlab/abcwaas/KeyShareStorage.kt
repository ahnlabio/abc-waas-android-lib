package io.ahnlab.abcwaas

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class StoredKeyShare(
    val keyId: String,
    val encryptedShare: String,
    val secretStore: String,
    val curve: String
)

/**
 * KeyShareStorage
 * Android Keystore 기반 암호화된 키쉐어 저장소
 * EncryptedSharedPreferences를 사용하여 AES256으로 암호화
 */
public class KeyShareStorage(private val context: Context) {

    companion object {
        private const val TAG = "KeyShareStorage"
        private const val PREFS_FILE_NAME = "abc_waas_keyshare_storage"
        private const val KEY_PREFIX = "keyshare_"
    }

    private val json = Json { ignoreUnknownKeys = true }

    private val sharedPreferences: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context, MasterKey.DEFAULT_MASTER_KEY_ALIAS)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            PREFS_FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    /**
     * 키쉐어를 저장합니다.
     * @param keyShare 저장할 키쉐어 데이터
     */
    fun store(keyShare: StoredKeyShare) {
        val key = KEY_PREFIX + keyShare.curve
        val value = json.encodeToString(keyShare)
        sharedPreferences.edit().putString(key, value).apply()
        Log.d(TAG, "Stored key share for curve: ${keyShare.curve}")
    }

    /**
     * 특정 curve의 키쉐어를 조회합니다.
     * @param curve 조회할 curve (예: "secp256k1", "ed25519")
     * @return 저장된 키쉐어 또는 null
     */
    fun get(curve: String): StoredKeyShare? {
        val key = KEY_PREFIX + curve
        val value = sharedPreferences.getString(key, null) ?: return null
        return try {
            json.decodeFromString<StoredKeyShare>(value)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decode key share for curve: $curve", e)
            null
        }
    }

    /**
     * 특정 curve의 키쉐어를 삭제합니다.
     * @param curve 삭제할 curve
     */
    fun delete(curve: String) {
        val key = KEY_PREFIX + curve
        sharedPreferences.edit().remove(key).apply()
        Log.d(TAG, "Deleted key share for curve: $curve")
    }

    /**
     * 저장된 모든 키쉐어를 삭제합니다.
     */
    fun clear() {
        val editor = sharedPreferences.edit()
        sharedPreferences.all.keys
            .filter { it.startsWith(KEY_PREFIX) }
            .forEach { editor.remove(it) }
        editor.apply()
        Log.d(TAG, "Cleared all key shares")
    }

    /**
     * 특정 curve의 키쉐어가 저장되어 있는지 확인합니다.
     * @param curve 확인할 curve
     * @return 저장 여부
     */
    fun has(curve: String): Boolean {
        val key = KEY_PREFIX + curve
        return sharedPreferences.contains(key)
    }
}
