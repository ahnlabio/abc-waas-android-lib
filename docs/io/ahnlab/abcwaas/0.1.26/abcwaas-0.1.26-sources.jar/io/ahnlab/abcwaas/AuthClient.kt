package io.ahnlab.abcwaas

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

sealed class AuthError(override val message: String) : Exception(message) {
    object InvalidJsonFormat : AuthError("Invalid JSON format.")
    object NoData : AuthError("No data in response.")
    class DecodingError(val originalError: Throwable, val jsonString: String = "") : 
        AuthError("Decoding error: ${originalError.localizedMessage}\nJSON data: $jsonString")
    object ClientInitializationFailed : AuthError("Failed to initialize WAAS client.")
    class OperationFailed(val errorMessage: String) : AuthError("WAAS operation failed: $errorMessage")
    
    // Exception.message는 이미 상속받았으므로 추가 description 프로퍼티는 필요 없습니다.
    // 필요하다면 아래처럼 구현할 수 있습니다.
    val description: String
        get() = message
}

// JSON 설정
private val json = Json {
    ignoreUnknownKeys = true  // 모델에 없는 키는 무시
    isLenient = true          // 따옴표 없는 키 등 허용
    coerceInputValues = true  // 기본값이 있는 경우 누락된 필드 처리
}

class AuthClient private constructor() {
    private var clientPtr: Long = 0

    companion object {
        init {
            System.loadLibrary("abc_waas_core_mobile")
        }

        @JvmStatic
        fun create(
            baseUrl: String,
            accessKey: String,
            accessSecret: String,
            serviceId: String
        ): AuthClient {
            val client = AuthClient()
            client.clientPtr = createClient(
                baseUrl,
                "android",
                accessKey,
                accessSecret,
                serviceId
            )
            return client
        }

        @JvmStatic
        private external fun createClient(
            baseUrl: String,
            platform: String,
            accessKey: String,
            accessSecret: String,
            serviceId: String
        ): Long
    }

    suspend fun sendLoginCode(
        email: String,
        lang: String
    ): Result<AuthResponse<Unit>> = withContext(Dispatchers.IO) {
        val jsonResult = sendLoginCode(clientPtr, email, lang)
        try {
            val response = json.decodeFromString<AuthResponse<Unit>>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Log.e("AuthClient", "Error sending login code", e)
            Result.failure(AuthError.DecodingError(e, jsonResult))
        }
    }

    suspend fun verifyLoginCode(
        email: String,
        code: String
    ): Result<AuthResponse<Unit>> = withContext(Dispatchers.IO) {
        val jsonResult = verifyLoginCode(clientPtr, email, code)
        try {
            val response = json.decodeFromString<AuthResponse<Unit>>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Log.e("AuthClient", "Error verifying login code", e)
            Result.failure(AuthError.DecodingError(e, jsonResult))
        }
    }

    suspend fun login(
        grantType: String,
        email: String,
        password: String
    ): Result<AuthResponse<LoginResponse>> = withContext(Dispatchers.IO) {
        val jsonResult = login(clientPtr, grantType, email, password)
        try {
            val response = json.decodeFromString<AuthResponse<LoginResponse>>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Log.e("AuthClient", "Error logging in", e)
            Result.failure(AuthError.DecodingError(e, jsonResult))
        }
    }

    fun close() {
        destroyClient(clientPtr)
    }

    protected fun finalize() {
        close()
    }

    private external fun sendLoginCode(clientPtr: Long, email: String, lang: String): String
    private external fun verifyLoginCode(clientPtr: Long, email: String, code: String): String
    private external fun login(clientPtr: Long, grantType: String, email: String, password: String): String
    private external fun destroyClient(clientPtr: Long)
} 