package io.ahnlab.abcwaas

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class AuthResponse<T>(
    val code: Int,
    val msg: String,
    val data: T? = null
) {
    val isSuccess: Boolean
        get() = code == 0
}

@Serializable
data class LoginResponse(
    @SerialName("access_token")
    val accessToken: String,

    @SerialName("token_type")
    val tokenType: String,

    @SerialName("expire_in")
    val expireIn: Int,

    @SerialName("refresh_token")
    val refreshToken: String
)