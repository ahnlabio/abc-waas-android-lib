package io.ahnlab.abcwaas

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlinx.serialization.Serializable

sealed class WaasError(override val message: String) : Exception(message) {
    object InvalidJsonFormat : WaasError("Invalid JSON format.")
    object NoData : WaasError("No data in response.")
    class DecodingError(val originalError: Throwable, val jsonString: String = "") : 
        WaasError("Decoding error: ${originalError.localizedMessage}\nJSON data: $jsonString")
    object ClientInitializationFailed : WaasError("Failed to initialize WAAS client.")
    class OperationFailed(val errorMessage: String) : WaasError("WAAS operation failed: $errorMessage")
    
    // Exception.message는 이미 상속받았으므로 추가 description 프로퍼티는 필요 없습니다.
    // 필요하다면 아래처럼 구현할 수 있습니다.
    val description: String
        get() = message
}

// JSON 설정
private val json = Json {
    ignoreUnknownKeys = true  // 모델에 없는 키는 무시
    isLenient = true          // 따옴표 없는 키 등 허용
    coerceInputValues = true  // 기본값이 있는 경우 누락된 필드 처리
}

// String 확장 함수로 hasErrorType 추가
fun String.hasErrorType(): Boolean {
    Log.d("WaasClient", "hasErrorType: $this")
    return try {
        val jsonObject = JSONObject(this)
        hasErrorTypeRecursive(jsonObject)
    } catch (e: Exception) {
        false
    }
}

private fun hasErrorTypeRecursive(jsonObject: JSONObject): Boolean {
    val keys = jsonObject.keys()
    while (keys.hasNext()) {
        val key = keys.next()
        if (key == "error_type") {
            val value = jsonObject.opt(key)
            if (value != null && value != JSONObject.NULL && value.toString().isNotEmpty()) {
                return true
            }
        } else {
            val value = jsonObject.opt(key)
            if (value is JSONObject && hasErrorTypeRecursive(value)) {
                return true
            }
        }
    }
    return false
}

class WaasClient private constructor() {
    private var clientPtr: Long = 0

    companion object {
        init {
            System.loadLibrary("abc_waas_core_mobile")
        }

        @JvmStatic
        fun create(baseUrl: String): WaasClient {
            val client = WaasClient()
            client.clientPtr = createClient(baseUrl)
            return client
        }

        @JvmStatic
        private external fun createClient(baseUrl: String): Long
    }

    suspend fun getV3Wallet(
        accessToken: String
    ): Result<WalletResponse> = withContext(Dispatchers.IO) {
        val jsonResult = getV3Wallet(clientPtr, accessToken)
        try {
            val response = json.decodeFromString<WalletResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Log.e("WaasClient", "Error getting wallet", e)
            Result.failure(WaasError.DecodingError(e, jsonResult))
        }
    }

    suspend fun getV3WalletKey(
        accessToken: String
    ): Result<WalletKeyResponse> = withContext(Dispatchers.IO) {
        val jsonResult = getV3WalletKey(clientPtr, accessToken)
        try {
            val response = json.decodeFromString<WalletKeyResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(WaasError.DecodingError(e, jsonResult))
        }
    }

    suspend fun getV3WalletUser(
        accessToken: String
    ): Result<WalletUserResponse> = withContext(Dispatchers.IO) {
        val jsonResult = getV3WalletUser(clientPtr, accessToken)
        try {
            val response = json.decodeFromString<WalletUserResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(WaasError.DecodingError(e, jsonResult))
        }
    }

    suspend fun getV3WalletToken(
        accessToken: String,
        id: String
    ): Result<WalletTokenResponse> = withContext(Dispatchers.IO) {
        val jsonResult = getV3WalletToken(clientPtr, accessToken, id)
        try {
            val response = json.decodeFromString<WalletTokenResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(WaasError.DecodingError(e, jsonResult))
        }
    }

    suspend fun postV3WalletKey(
        accessToken: String,
        id: String,
        curve: String,
        publicKey: String
    ): Result<WalletKey> = withContext(Dispatchers.IO) { 
        val jsonResult = postV3WalletKey(clientPtr, accessToken, id, curve, publicKey)
        try {
            val response = json.decodeFromString<WalletKey>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(WaasError.DecodingError(e, jsonResult))
        }
    }

    fun close() {
        destroyClient(clientPtr)
    }

    protected fun finalize() {
        close()
    }

    private external fun getV3Wallet(clientPtr: Long, accessToken: String): String
    private external fun getV3WalletKey(clientPtr: Long, accessToken: String): String
    private external fun getV3WalletUser(clientPtr: Long, accessToken: String): String
    private external fun getV3WalletToken(clientPtr: Long, accessToken: String, id: String): String
    private external fun postV3WalletKey(clientPtr: Long, accessToken: String, id: String, curve: String, publicKey: String): String

    
    private external fun destroyClient(clientPtr: Long)
}

