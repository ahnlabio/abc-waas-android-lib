package io.ahnlab.abcwaas

import androidx.constraintlayout.solver.widgets.Helper
import io.ahnlab.abcmpc.GenerateShareResponse
import io.ahnlab.abcwaas.WaasClient
import io.ahnlab.abcwaas.WaasError
import io.ahnlab.abcwaas.WalletKeyResponse
import io.ahnlab.abcmpc.ABCMpc
import io.ahnlab.abcmpc.MpcError
import io.ahnlab.abcmpc.RecoverShareResponse
import io.ahnlab.abcmpc.SignResponse
import io.ahnlab.abcmpc.ValidatePasswordAndSecretStoreResponse
import io.ahnlab.abcmpc.ValidateShareAndSecretStoreResponse
import org.json.JSONObject

sealed class HelperError(override val message: String) : Exception(message) {
    class WaasError(val error: io.ahnlab.abcwaas.WaasError) :
        HelperError("Waas error: ${error.message}")
    
    class MpcError(val error: io.ahnlab.abcmpc.MpcError) :
        HelperError("Mpc error: ${error.message}")
    
    class UnknownError(override val message: String) : 
        HelperError(message)

    val description: String
        get() = message
}

public class WaasHelper(
    private val waasClient: WaasClient?,
    private val node1BaseURL: String,
    private val node2BaseURL: String
) {

    public suspend fun generateKeyShare(
        accessToken: String,
        curve:String,
        password:String
    ): Result<GenerateShareResponse> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(HelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. User 키 존재 확인
            val userKeyResult = waasClient.getV3WalletKey(accessToken)
            if (userKeyResult.isFailure) {
                return when (val error = userKeyResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet data fetch failed"))
                }
            }
            val walletKeyResponse = userKeyResult.getOrThrow()

            val curveKeyResult = checkForDuplicateKey(walletKeyResponse, curve)
            if (curveKeyResult.isFailure) {
                return when (val error = curveKeyResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Duplicate key check failed"))
                }
            }

            // 2. 키 ID 생성
            val keyIdResult = ABCMpc.getInstance().generate_key_id()
            if (keyIdResult.isFailure) {
                return when (val error = keyIdResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Key ID generation failed"))
                }
            }
            val keyIdResponse = keyIdResult.getOrThrow()

            // 3. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyIdResponse.result)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Token Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 4. 쉐어 생성
            val generateShareResult = ABCMpc.getInstance().generate_share(
                node_1_url = node1BaseURL,
                node_2_url = node2BaseURL,
                key_id = keyIdResponse.result,
                token = walletTokenResponse.token,
                curve = curve,
                password = password
            )
            if (generateShareResult.isFailure) {
                return when (val error = generateShareResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Key Share Generation Failed"))
                }
            }
            val generateShareResponse = generateShareResult.getOrThrow()

            // 5. 공개 키 생성
            val publicKeyResult = ABCMpc.getInstance().public_key(
                key_id = generateShareResponse.keyId,
                encrypted_share = generateShareResponse.encryptedShare,
                secret_store = generateShareResponse.secretStore,
                curve = generateShareResponse.curve,
                password = password
            )
            if (publicKeyResult.isFailure) {
                return when (val error = publicKeyResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Public Key Generation Failed"))
                }
            }
            val publicKeyResponse = publicKeyResult.getOrThrow()

            // 6. 지갑 키 등록
            val postWalletResult = waasClient.postV3WalletKey(
                accessToken = accessToken,
                id = generateShareResponse.keyId,
                curve = generateShareResponse.curve,
                publicKey = publicKeyResponse.result
            )
            if (postWalletResult.isFailure) {
                return when (val error = postWalletResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Key Registration Failed"))
                }
            }
            postWalletResult.getOrThrow()

            // 7. 성공 처리
            return Result.success(generateShareResponse)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun recoverKeyShare(
        accessToken: String,
        curve:String,
        password:String
    ): Result<RecoverShareResponse> {
        return try {


            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(HelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. User 키 존재 확인
            val userKeyResult = waasClient.getV3WalletKey(accessToken)
            if (userKeyResult.isFailure) {
                return when (val error = userKeyResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet data fetch failed"))
                }
            }
            val walletKeyResponse = userKeyResult.getOrThrow()

            // 일치하는 키 찾기
            var foundMatchingKey = false
            var sourceKeyId = ""
            for (key in walletKeyResponse) {
                if (key.curve == curve) {
                    foundMatchingKey = true
                    sourceKeyId = key.id
                    break
                }
            }

            // 일치하는 키를 찾지 못한 경우
            if (!foundMatchingKey) {
                return Result.failure(HelperError.UnknownError("No key found with the specified curve and key_id"))
            }

            // 필수 키 확인
            val curveKeyResult = checkForRequiredKey(walletKeyResponse, curve)
            if (curveKeyResult.isFailure) {
                return when (val error = curveKeyResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("No key found with the specified curve and key_id"))
                }
            }

            // 2. 키 ID 생성
            val keyIdResult = ABCMpc.getInstance().generate_key_id()
            if (keyIdResult.isFailure) {
                return when (val error = keyIdResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Key ID generation failed"))
                }
            }
            val keyIdResponse = keyIdResult.getOrThrow()

            // 3. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyIdResponse.result)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Token Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 4. 쉐어 생성
            val recoverShareResult = ABCMpc.getInstance().recover_share(
                node_1_url = node1BaseURL,
                node_2_url = node2BaseURL,
                token = walletTokenResponse.token,
                target_key_id = keyIdResponse.result,
                source_key_id = sourceKeyId,
                curve = curve,
                password = password
            )
            if (recoverShareResult.isFailure) {
                return when (val error = recoverShareResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Key Share Recovery Failed"))
                }
            }
            val recoverShareResponse = recoverShareResult.getOrThrow()

            // 5. 공개 키 생성
            val publicKeyResult = ABCMpc.getInstance().public_key(
                key_id = recoverShareResponse.keyId,
                encrypted_share = recoverShareResponse.encryptedShare,
                secret_store = recoverShareResponse.secretStore,
                curve = recoverShareResponse.curve,
                password = password
            )
            if (publicKeyResult.isFailure) {
                return when (val error = publicKeyResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Public Key Generation Failed"))
                }
            }
            val publicKeyResponse = publicKeyResult.getOrThrow()

            // 6. 지갑 키 등록
            val postWalletResult = waasClient.postV3WalletKey(
                accessToken = accessToken,
                id = recoverShareResponse.keyId,
                curve = recoverShareResponse.curve,
                publicKey = publicKeyResponse.result
            )
            if (postWalletResult.isFailure) {
                return when (val error = postWalletResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Key Registration Failed"))
                }
            }
            postWalletResult.getOrThrow()

            // 7. 성공 처리
            return Result.success(recoverShareResponse)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun sign(
        accessToken: String,
        keyId: String,
        encryptedShare: String,
        secretStore: String,
        curve:String,
        message:String,
        password: String
    ): Result<SignResponse> {
        return try {


            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(HelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyId)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Token Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 2. 서명
            val signResult = ABCMpc.getInstance().sign(
                node_1_url = node1BaseURL,
                token = walletTokenResponse.token,
                key_id = keyId,
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                curve = curve,
                message = message,
                password = password
            )
            if (signResult.isFailure) {
                return when (val error = signResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Message Signing Failed"))
                }
            }
            val signResponse = signResult.getOrThrow()

            return Result.success(signResponse)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun signMta(
        accessToken: String,
        keyId: String,
        encryptedShare: String,
        secretStore: String,
        message: String,
        password: String
    ): Result<SignResponse> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(HelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyId)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Token Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 2. MTA 서명
            val signResult = ABCMpc.getInstance().sign_mta(
                node_1_url = node1BaseURL,
                token = walletTokenResponse.token,
                key_id = keyId,
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                message = message,
                password = password
            )
            if (signResult.isFailure) {
                return when (val error = signResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("MTA Message Signing Failed"))
                }
            }
            val signResponse = signResult.getOrThrow()

            return Result.success(signResponse)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun signMtaDerived(
        accessToken: String,
        keyId: String,
        encryptedShare: String,
        secretStore: String,
        message: String,
        chainCode: String,
        path: String,
        password: String
    ): Result<SignResponse> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(HelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyId)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Token Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 2. MTA 파생 서명
            val signResult = ABCMpc.getInstance().sign_mta_derived(
                node_1_url = node1BaseURL,
                token = walletTokenResponse.token,
                key_id = keyId,
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                message = message,
                chain_code = chainCode,
                path = path,
                password = password
            )
            if (signResult.isFailure) {
                return when (val error = signResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("MTA Derived Message Signing Failed"))
                }
            }
            val signResponse = signResult.getOrThrow()

            return Result.success(signResponse)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun signWithChainCode(
        accessToken: String,
        keyId: String,
        encryptedShare: String,
        secretStore: String,
        curve: String,
        message: String,
        chainCode: String,
        path: String,
        password: String
    ): Result<SignResponse> {
        return try {
            // 0. waasClient 널 체크
            if (waasClient == null) {
                return Result.failure(HelperError.UnknownError("WaasClient is not initialized"))
            }

            // 1. 지갑 토큰 가져오기
            val tokenResult = waasClient.getV3WalletToken(accessToken, keyId)
            if (tokenResult.isFailure) {
                return when (val error = tokenResult.exceptionOrNull()) {
                    is WaasError -> Result.failure(HelperError.WaasError(error))
                    else -> Result.failure(HelperError.UnknownError("Wallet Token Fetch Failed"))
                }
            }
            val walletTokenResponse = tokenResult.getOrThrow()

            // 2. 체인코드 파생 서명
            val signResult = ABCMpc.getInstance().sign_with_chain_code(
                node_1_url = node1BaseURL,
                token = walletTokenResponse.token,
                key_id = keyId,
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                curve = curve,
                message = message,
                chain_code = chainCode,
                path = path,
                password = password
            )
            if (signResult.isFailure) {
                return when (val error = signResult.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("ChainCode Derived Message Signing Failed"))
                }
            }
            val signResponse = signResult.getOrThrow()

            return Result.success(signResponse)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun publicKeyWithChainCode(
        keyId: String,
        encryptedShare: String,
        secretStore: String,
        curve: String,
        chainCode: String,
        path: String,
        password: String
    ): Result<io.ahnlab.abcmpc.PublicKeyResponse> {
        return try {
            val result = ABCMpc.getInstance().public_key_with_chain_code(
                key_id = keyId,
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                curve = curve,
                chain_code = chainCode,
                path = path,
                password = password
            )
            if (result.isFailure) {
                return when (val error = result.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Public Key With ChainCode Generation Failed"))
                }
            }
            val response = result.getOrThrow()

            return Result.success(response)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun validatePassword(password: String, secretStore: String): Result<ValidatePasswordAndSecretStoreResponse> {
        return try {
            val result = ABCMpc.getInstance().validate_password_and_secret_store(
                password = password,
                secret_store = secretStore
            )
            if (result.isFailure) {
                return when (val error = result.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Password Validation Failed"))
                }
            }
            val response = result.getOrThrow()

            return Result.success(response)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    public suspend fun validateShare(encryptedShare: String, secretStore: String, password: String): Result<ValidateShareAndSecretStoreResponse> {
        return try {


            val result = ABCMpc.getInstance().validate_share_and_secret_store(
                encrypted_share = encryptedShare,
                secret_store = secretStore,
                password = password
            )
            if (result.isFailure) {
                return when (val error = result.exceptionOrNull()) {
                    is MpcError -> Result.failure(HelperError.MpcError(error))
                    else -> Result.failure(HelperError.UnknownError("Share Validation Failed"))
                }
            }
            val response = result.getOrThrow()

            return Result.success(response)
        } catch (e: Exception) {
            Result.failure(HelperError.UnknownError("error: ${e.localizedMessage}"))
        }
    }

    // 1. 중복 키 확인 (키가 이미 존재하면 에러 반환)
    private fun checkForDuplicateKey(walletKeyResponse: WalletKeyResponse, curve: String): Result<Unit> {
        // walletKeyResponse 배열에서 주어진 curve와 일치하는 요소가 있는지 확인
        if (walletKeyResponse.any { it.curve == curve }) {
            // 이미 존재하는 경우 에러 반환
            return Result.failure(HelperError.WaasError(WaasError.OperationFailed("$curve key already exists for this user. Cannot create duplicate key")))
        }

        // 존재하지 않는 경우 성공 반환
        return Result.success(Unit)
    }

    // 2. 필요한 키 확인 (키가 존재하지 않으면 에러 반환)
    private fun checkForRequiredKey(walletKeyResponse: WalletKeyResponse, curve: String): Result<Unit> {
        // walletKeyResponse 배열에서 주어진 curve와 일치하는 요소가 있는지 확인
        if (!walletKeyResponse.any { it.curve == curve }) {
            // 존재하지 않는 경우 에러 반환
            return Result.failure(
                HelperError.WaasError(
                    WaasError.OperationFailed("No $curve key exists for this user. Please create the key first.")
                )
            )
        }
        
        // 존재하는 경우 성공 반환
        return Result.success(Unit)
    }
}